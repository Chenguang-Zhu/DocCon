approve = event => approvals.value += event.target.innerText + '\n'
