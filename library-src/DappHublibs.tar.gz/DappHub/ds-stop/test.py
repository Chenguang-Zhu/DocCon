import os 
import json
from pickletools import optimize 
import re 
# Cycle dependency
from typing import TYPE_CHECKING, List, Optional
optimized = False
targets_json = None 
with open(os.path.join("./out", "dapp.sol.json"), "r", encoding="utf8") as file_desc:
            targets_json = json.load(file_desc)

            version: Optional[str] = None
            if "version" in targets_json:
                version = re.findall(r"\d+\.\d+\.\d+", targets_json["version"])[0]

            for original_filename, contracts_info in targets_json["contracts"].items():
                for original_contract_name, info in contracts_info.items():
                    if "metadata" in info:
                        try:
                            metadata = json.loads(info["metadata"])
                            # print(metadata)
                            if (
                                "settings" in metadata
                                and "optimizer" in metadata["settings"]
                                and "enabled" in metadata["settings"]["optimizer"]
                            ):
                                optimized |= metadata["settings"]["optimizer"]["enabled"]
                        except:
                            # print(original_filename)
                            # print(original_contract_name)
                            # print(info)
                            # print(info["metadata"])
                            info["metadata"] = json.dumps(dict())
                            print(info["metadata"])
                            # raise Exception("unkown")
            
with open("./out/dapp.sol.json", "w") as f:
            json.dump(targets_json, f)